-- Creating special users 
GRANT ALL PRIVILEGES ON *.* TO 'garellano'@'%' IDENTIFIED BY 'garellano' with GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO 'garellano'@'localhost' IDENTIFIED BY 'garellano' with GRANT OPTION;

-- Creating and using 'database'
DROP DATABASE IF EXISTS ejemplo;
CREATE DATABASE ejemplo;

